﻿namespace Nexus.Permissions.Export.Models.Enums;

public enum PermissionType
{
    User,
    Domain,
    Sharepoint,
    Security
}