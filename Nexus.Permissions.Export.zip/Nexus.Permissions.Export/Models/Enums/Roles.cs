﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nexus.Permissions.Export.Models.Enums;
public enum Roles
{
    Owner,
    Read
}
